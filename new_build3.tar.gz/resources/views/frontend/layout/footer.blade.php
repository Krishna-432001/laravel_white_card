<footer class="bg-dark text-white py-4">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5>About Us</h5>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus imperdiet, nulla sit amet volutpat.</p>
            </div>
            <div class="col-md-4">
                <h5>Links</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-white">Home</a></li>
                    <li><a href="#" class="text-white">Features</a></li>
                    <li><a href="#" class="text-white">Pricing</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5>Contact</h5>
                <p>Email: example@example.com</p>
                <p>Phone: (123) 456-7890</p>
            </div>
        </div>
    </div>
    <div class="text-center py-3">
        &copy; 2024 Your Company
    </div>
</footer>